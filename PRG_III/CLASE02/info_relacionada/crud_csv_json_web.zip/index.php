<?php
    $dato = $_SERVER['REQUEST_METHOD'];
    
    
    // decidir si el get tiene valor o no
    // listar todos lo del archivo o el alumno solicitado

    if($dato == "GET")
    {
        require_once("Funciones/lista_alumnos.php");
    }
    
    if($dato == "POST")
    {
        require_once("Funciones/crea_alumnos.php");
        
        echo $miAlumno->retornarJSON();
        echo "<br><br>";
        var_dump($miAlumno);
    }
    
    if($dato == "PUT")
    {
        require_once("Funciones/modifica_alumnos.php");
    }
    
    if($dato == "DELETE")
    {
        require_once("Funciones/borra_alumnos.php");
    }

?>