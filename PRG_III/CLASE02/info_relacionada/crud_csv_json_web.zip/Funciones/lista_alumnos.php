<?php

    include_once("Entidades/alumno.php");
    
    if(!isset($_GET['legajo']))
    {
        
        // agregar file exist ?
        $arrAlumnos = Alumno::leerCSV("Archivos/ListadoAlumnos.txt", "r");
        listarAlumnos($arrAlumnos);
    }
    
    if(isset($_GET['legajo']))
    {
        
    }
    
    
    
    function listarAlumnos($arr)
    {
        foreach($arr as $alumno)
        {
            echo $alumno . "<br>";
        }
    }

    
    

?>